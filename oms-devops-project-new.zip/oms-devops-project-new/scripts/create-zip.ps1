# ===================================
# OMS Project - Create Distribution ZIP
# ===================================
# This script creates a clean ZIP file of the project
# excluding all library folders (node_modules, __pycache__, etc.)

$projectName = "oms-devops-project"
$zipName = "$projectName-$(Get-Date -Format 'yyyy-MM-dd').zip"
$outputPath = "..\$zipName"

Write-Host "Creating distribution ZIP file..." -ForegroundColor Cyan
Write-Host ""

# Create temp directory
$tempDir = "$env:TEMP\$projectName-dist"
if (Test-Path $tempDir) {
    Remove-Item -Recurse -Force $tempDir
}
New-Item -ItemType Directory -Path $tempDir | Out-Null

Write-Host "Copying project files (excluding libraries)..." -ForegroundColor Yellow

# Use robocopy to copy files excluding specified folders
$source = Get-Location
robocopy $source $tempDir /E /XD node_modules __pycache__ .venv venv .git .next dist build .cache .pytest_cache /XF *.pyc .DS_Store Thumbs.db /NFL /NDL /NJH /NJS /NC /NS /NP

# Remove old zip if exists
if (Test-Path $outputPath) {
    Remove-Item $outputPath -Force
}

Write-Host "Creating ZIP archive..." -ForegroundColor Yellow

# Create ZIP
Compress-Archive -Path "$tempDir\*" -DestinationPath $outputPath -Force

# Cleanup temp directory
Remove-Item -Recurse -Force $tempDir

# Get file size
$zipFile = Get-Item $outputPath
$sizeMB = [math]::Round($zipFile.Length / 1MB, 2)

Write-Host ""
Write-Host "ZIP file created successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "Location: $((Resolve-Path $outputPath).Path)" -ForegroundColor White
Write-Host "Size: $sizeMB MB" -ForegroundColor White
Write-Host ""
Write-Host "To run the project, users just need Docker!" -ForegroundColor Green
Write-Host "See README.md for instructions." -ForegroundColor White
