from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
from openai import OpenAI
import mysql.connector
from dotenv import load_dotenv
import json

# Carregar variáveis de ambiente
# Caregar variáveis de ambiente (Verufucar o diretório atual e o diretório pai)
load_dotenv()
load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '.env'))
load_dotenv(os.path.join(os.getcwd(), '..', '.env'))

# Inicializar FastAPI app
app = FastAPI(
    title="OMS AI Query Agent",
    description="Natural language to SQL query interface for OMS database",
    version="1.0.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

print("\n🚀 --- AI AGENT DIAGNOSTICS ---")
print(f"Working Directory: {os.getcwd()}")
print(f"OpenRouter Key Found: {'✅ Yes' if os.getenv('OPENROUTER_API_KEY') else '❌ No'}")
print(f"AI Model: {os.getenv('AI_MODEL', 'openai/gpt-oss-20b:free')}")
print(f"DB Host: {os.getenv('DB_HOST', 'localhost')}")
print("-------------------------------\n")

# Inicializar OpenAI client para OpenRouter
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=os.getenv("OPENROUTER_API_KEY")
)

# Configurar Database 
DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", 3306)),
    "database": os.getenv("DB_NAME", "oms_db"),
    "user": os.getenv("DB_USER", "oms_user"),
    "password": os.getenv("DB_PASSWORD", "oms_password"),
}

# Modelos de pedido/resposta
class QueryRequest(BaseModel):
    question: str

class QueryResponse(BaseModel):
    sql: str
    data: list
    explanation: str
    reasoning: str = ""

# Esquema de base de dados para contexto
DATABASE_SCHEMA = """
Database Schema:

1. users - User information
   - id (bigint)
   - email (varchar)
   - first_name (varchar)
   - last_name (varchar)
   - role (enum: customer, staff, admin)
   - created_at (timestamp)

2. products - Product catalog
   - id (bigint)
   - name (varchar)
   - sku (varchar)
   - price (decimal)
   - stock_quantity (int)
   - category_id (bigint)
   - is_active (boolean)

3. orders - Order records
   - id (bigint)
   - user_id (bigint)
   - order_number (varchar)
   - status (enum: pending, processing, shipped, delivered, cancelled, refunded)
   - payment_status (enum: pending, paid, failed, refunded)
   - subtotal (decimal)
   - tax_amount (decimal)
   - shipping_amount (decimal)
   - total_amount (decimal)
   - created_at (timestamp)

4. order_items - Items in each order
   - id (bigint)
   - order_id (bigint)
   - product_id (bigint)
   - product_name (varchar)
   - quantity (int)
   - unit_price (decimal)
   - total (decimal)

5. payments - Payment records
   - id (bigint)
   - order_id (bigint)
   - payment_method (enum)
   - amount (decimal)
   - status (enum: pending, completed, failed, refunded)

6. shipments - Shipping information
   - id (bigint)
   - order_id (bigint)
   - tracking_number (varchar)
   - carrier (varchar)
   - status (enum: pending, in_transit, delivered, returned)
"""

def get_db_connection():
    """Create database connection"""
    return mysql.connector.connect(**DB_CONFIG)

def is_safe_query(sql: str) -> bool:
    """Check if SQL query is safe (SELECT only, no modifications)"""
    import re
    sql_upper = sql.strip().upper()
    
    # Permitir apenas consultas SELECT
    if not sql_upper.startswith("SELECT"):
        return False
    
    # Bloquear palavras-chave perigosas (utilizando limites de palavras para evitar falsos positivos como DATE_SUB)
    dangerous_keywords = [
        r"\bDROP\b", r"\bDELETE\b", r"\bINSERT\b", r"\bUPDATE\b", r"\bALTER\b", r"\bCREATE\b",
        r"\bTRUNCATE\b", r"\bREPLACE\b", r"\bGRANT\b", r"\bREVOKE\b", r"\bEXEC\b"
    ]
    
    for pattern in dangerous_keywords:
        if re.search(pattern, sql_upper):
            return False
    
    return True

def generate_sql(question: str) -> str:
    """Use OpenAI to generate SQL from natural language"""
    
    system_prompt = f"""You are an expert SQL generator for a MySQL database.
Generate ONLY valid MySQL SELECT queries based on the user's question.

{DATABASE_SCHEMA}

Rules:
1. Generate ONLY SELECT queries
2. Use proper MySQL syntax
3. Use JOINs when querying multiple tables
4. Use appropriate WHERE clauses for filtering
5. Use GROUP BY and aggregate functions when needed
6. Return ONLY the SQL query, no explanations or additional text
7. Do not use semicolons at the end
8. Use table and column names exactly as shown in the schema
9. For date/time queries, use CURDATE(), DATE_SUB(), etc.

Examples:
Question: "Show me all orders from last month"
SQL: SELECT * FROM orders WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)

Question: "Top 5 customers by spending"
SQL: SELECT u.id, u.first_name, u.last_name, SUM(o.total_amount) as total_spent FROM users u JOIN orders o ON u.id = o.user_id GROUP BY u.id, u.first_name, u.last_name ORDER BY total_spent DESC LIMIT 5

Now generate SQL for the user's question."""

    try:
        response = client.chat.completions.create(
            model=os.getenv("AI_MODEL", "openai/gpt-oss-20b:free"),
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question}
            ],
            temperature=0.0,
            max_tokens=1000,
            extra_body={"reasoning": {"enabled": True}}
        )
        
        sql = response.choices[0].message.content.strip()
        reasoning_raw = getattr(response.choices[0].message, "reasoning_details", "")
        
        # OpenRouter's reasoning_details can be a list of dicts or a string
        if isinstance(reasoning_raw, list):
            reasoning = "\n".join([str(r.get('content', r)) if isinstance(r, dict) else str(r) for r in reasoning_raw])
        else:
            reasoning = str(reasoning_raw)
        
        # Remove markdown code blocks if present
        if sql.startswith("```"):
            lines = sql.split("\n")
            sql = "\n".join(lines[1:-1])  # Remove first and last lines
        
        sql = sql.replace("```sql", "").replace("```", "").strip()
        
        return sql, reasoning
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to generate SQL: {str(e)}")

def execute_sql(sql: str) -> list:
    """Execute SQL query and return results"""
    if not is_safe_query(sql):
        raise HTTPException(status_code=400, detail="Unsafe query detected. Only SELECT queries are allowed.")
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute(sql)
        results = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        # Convert decimal and datetime to JSON serializable types
        for row in results:
            for key, value in row.items():
                if hasattr(value, 'isoformat'):  # datetime
                    row[key] = value.isoformat()
                elif hasattr(value, '__float__'):  # Decimal
                    row[key] = float(value)
        
        return results
    except mysql.connector.Error as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Error executing query: {str(e)}")

def generate_explanation(question: str, sql: str, row_count: int) -> str:
    """Generate human-readable explanation of the query"""
    return f"I found {row_count} result(s) for your question: '{question}'. The query searched the database using: {sql}"

# API Endpoints

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "OMS AI Query Agent",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "query": "/ai/query",
            "examples": "/ai/examples"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        conn = get_db_connection()
        conn.close()
        db_status = "connected"
    except Exception as e:
        db_status = f"error: {str(e)}"
    
    # Test OpenAI API
    openai_status = "configured" if os.getenv("OPENAI_API_KEY") else "not configured"
    
    return {
        "status": "ok",
        "database": db_status,
        "openai": openai_status
    }

@app.post("/ai/query", response_model=QueryResponse)
async def query_database(request: QueryRequest):
    """Process natural language query and return SQL results"""
    print(f"🔍 DEBUG: New Question received: '{request.question}'")
    
    if not request.question or len(request.question.strip()) == 0:
        raise HTTPException(status_code=400, detail="Question cannot be empty")
    
    try:
        # Generate SQL from natural language
        print("🤖 DEBUG: Calling OpenRouter for SQL generation...")
        sql, reasoning = generate_sql(request.question)
        print(f"✅ DEBUG: Generated SQL: {sql}")
    except Exception as e:
        print(f"❌ DEBUG: SQL Generation Failed: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"AI Agent failed to generate SQL: {str(e)}")
    
    try:
        # Execute SQL query
        print("🗄️ DEBUG: Executing SQL in Database...")
        data = execute_sql(sql)
        print(f"📊 DEBUG: Query successful. Found {len(data)} results")
    except Exception as e:
        print(f"❌ DEBUG: SQL Execution Failed: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Database query failed: {str(e)}")
    
    # Generate explanation
    explanation = generate_explanation(request.question, sql, len(data))
    
    return QueryResponse(
        sql=sql,
        data=data,
        explanation=explanation,
        reasoning=reasoning
    )

@app.get("/ai/examples")
async def get_examples():
    """Get example queries"""
    return {
        "examples": [
            "Show me all orders from last month",
            "What are the top 5 selling products?",
            "Find orders with pending payment status",
            "List customers who spent more than $1000",
            "Show me all cancelled orders",
            "What is the average order value?",
            "How many orders are currently being shipped?",
            "Show me products that are low in stock",
            "Who are the top 10 customers by total spending?",
            "Show me all orders placed today"
        ]
    }

# Run the application
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
