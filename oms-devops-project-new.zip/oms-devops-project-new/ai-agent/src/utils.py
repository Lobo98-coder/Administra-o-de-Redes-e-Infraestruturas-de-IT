"""
OMS AI Query Agent - Utility Functions
"""

def validate_sql_query(sql: str) -> tuple[bool, str]:
    """
    Validate SQL query for safety
    Returns: (is_valid, error_message)
    """
    sql_upper = sql.strip().upper()
    
    # tem de começar por SELECT
    if not sql_upper.startswith("SELECT"):
        return False, "Only SELECT queries are allowed"
    
    # Verificar palavras-chave perigosas
    dangerous = ["DROP", "DELETE", "INSERT", "UPDATE", "ALTER", "CREATE", "TRUNCATE"]
    for keyword in dangerous:
        if keyword in sql_upper:
            return False, f"Keyword '{keyword}' is not allowed"
    
    return True, ""

def format_results(results: list) -> str:
    """
    Format query results for display
    """
    if not results:
        return "No results found"
    
    # Obter nomes de colunas
    columns = list(results[0].keys())
    
    # Criar cabeçalho
    output = " | ".join(columns) + "\n"
    output += "-" * len(output) + "\n"
    
    # Adicionar linhas de dados
    for row in results:
        output += " | ".join(str(row[col]) for col in columns) + "\n"
    
    return output
