import { useState } from 'react';
import { aiAPI } from '../services/api';

function AIQuery() {
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const exampleQueries = [
    'Show me all orders from last month',
    'What are the top 5 selling products?',
    'Find orders with pending payment status',
    'List customers who spent more than $1000',
    'Show me all cancelled orders',
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setResult(null);

    try {
      const response = await aiAPI.query(question);
      console.log('AI Response:', response); // Debug log
      console.log('AI Data:', response.data); // Debug log
      setResult(response.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to process query');
    } finally {
      setLoading(false);
    }
  };

  const handleExampleClick = (query) => {
    setQuestion(query);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">AI Query Interface</h1>
        <p className="text-gray-600 mt-2">
          Ask questions about your data in natural language
        </p>
      </div>

      {/* Query Form */}
      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Question
            </label>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              rows="4"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="e.g., Show me all orders from last month..."
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading || !question.trim()}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-6 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            {loading ? (
              <span className="flex items-center justify-center">
                <svg
                  className="animate-spin h-5 w-5 mr-3"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                    fill="none"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
                Processing...
              </span>
            ) : (
              'Ask AI'
            )}
          </button>
        </form>
      </div>

      {/* Example Queries */}
      <div className="bg-blue-50 rounded-lg p-6 mb-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">
          Example Queries
        </h3>
        <div className="space-y-2">
          {exampleQueries.map((query, index) => (
            <button
              key={index}
              onClick={() => handleExampleClick(query)}
              className="block w-full text-left px-4 py-3 bg-white rounded-lg hover:bg-blue-100 transition text-gray-700"
            >
              💡 {query}
            </button>
          ))}
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
          <p className="font-medium">Error</p>
          <p className="text-sm">{error}</p>
        </div>
      )}

      {/* Result Display */}
      {result && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Results</h3>

          {result.reasoning && (
            <div className="mb-4">
              <p className="text-sm font-medium text-gray-700 mb-2">
                AI Reasoning (Thought Process):
              </p>
              <div className="bg-purple-50 p-4 rounded-lg text-sm text-purple-900 border border-purple-100 italic">
                {result.reasoning}
              </div>
            </div>
          )}

          {result.sql && (
            <div className="mb-4">
              <p className="text-sm font-medium text-gray-700 mb-2">
                Generated SQL:
              </p>
              <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                <code>{result.sql}</code>
              </pre>
            </div>
          )}

          {result.data && Array.isArray(result.data) && result.data.length > 0 ? (
            <div className="overflow-x-auto border border-gray-200 rounded-lg">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    {Object.keys(result.data[0] || {}).map((key) => (
                      <th
                        key={key}
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        {key.replace(/_/g, ' ')}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {result.data.map((row, index) => (
                    <tr key={index} className="hover:bg-gray-50 transition-colors">
                      {Object.values(row || {}).map((value, i) => (
                        <td
                          key={i}
                          className="px-6 py-4 whitespace-nowrap text-sm text-gray-900"
                        >
                          {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-4 bg-yellow-50 text-yellow-700 rounded-lg border border-yellow-200">
              No data returned for this query.
            </div>
          )}

          {result.explanation && (
            <div className="mt-4 p-4 bg-blue-50 border border-blue-100 rounded-lg">
              <h4 className="text-sm font-bold text-blue-900 mb-1">AI Explanation:</h4>
              <p className="text-sm text-blue-800">{result.explanation}</p>
            </div>
          )}

          {/* Debug View */}
          <div className="mt-8 pt-4 border-t border-gray-200">
             <details>
               <summary className="text-xs text-gray-500 cursor-pointer">View Raw Debug Data</summary>
               <pre className="mt-2 bg-gray-50 p-4 rounded text-xs overflow-auto">
                 {JSON.stringify(result, null, 2)}
               </pre>
             </details>
          </div>
        </div>
      )}
    </div>
  );
}

export default AIQuery;
