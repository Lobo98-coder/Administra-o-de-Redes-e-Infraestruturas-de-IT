import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ordersAPI } from '../services/api';

function OrderDetails() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchOrder();
  }, [id]);

  const fetchOrder = async () => {
    try {
      const response = await ordersAPI.getById(id);
      setOrder(response.data.order);
    } catch (err) {
      console.error('Failed to fetch order:', err);
      setError('Failed to load order details. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <div className="bg-red-50 text-red-700 p-4 rounded-lg mb-4 inline-block">
          {error || 'Order not found'}
        </div>
        <br />
        <Link to="/orders" className="text-blue-600 hover:text-blue-800">
          &larr; Back to Orders
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <Link to="/orders" className="text-gray-500 hover:text-gray-700">
            &larr; Back
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Order #{order.orderNumber}</h1>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)} uppercase`}>
            {order.status}
          </span>
        </div>
        <div className="text-sm text-gray-500">
          Placed on {new Date(order.createdAt).toLocaleDateString()} at {new Date(order.createdAt).toLocaleTimeString()}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Order Items */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Items</h2>
            </div>
            <ul className="divide-y divide-gray-200">
              {order.items?.map((item) => (
                <li key={item.id} className="p-6 flex items-center">
                  <div className="flex-shrink-0 w-20 h-20 border border-gray-200 rounded overflow-hidden bg-gray-50">
                     {item.imageUrl ? (
                        <img
                          src={item.imageUrl}
                          alt={item.productName}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400">
                          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                        </div>
                      )}
                  </div>
                  <div className="ml-6 flex-1">
                    <div className="flex justify-between">
                      <h3 className="text-lg font-medium text-gray-900">{item.productName}</h3>
                      <p className="font-medium text-gray-900">${parseFloat(item.total).toFixed(2)}</p>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">SKU: {item.productSku}</p>
                    <div className="mt-2 text-sm text-gray-600">
                      Qty: {item.quantity} × ${parseFloat(item.unitPrice).toFixed(2)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Order Summary</h2>
            <dl className="space-y-3">
              <div className="flex justify-between text-sm text-gray-600">
                <dt>Subtotal</dt>
                <dd>${order.subtotal.toFixed(2)}</dd>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <dt>Tax</dt>
                <dd>${order.taxAmount.toFixed(2)}</dd>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <dt>Shipping</dt>
                <dd>${order.shippingAmount.toFixed(2)}</dd>
              </div>
              {order.discountAmount > 0 && (
                <div className="flex justify-between text-sm text-green-600">
                  <dt>Discount</dt>
                  <dd>-${order.discountAmount.toFixed(2)}</dd>
                </div>
              )}
              <div className="border-t border-gray-200 pt-3 flex justify-between text-base font-bold text-gray-900">
                <dt>Total</dt>
                <dd>${order.totalAmount.toFixed(2)}</dd>
              </div>
            </dl>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
             <h2 className="text-lg font-medium text-gray-900 mb-4">Customer Details</h2>
             <div className="text-sm text-gray-600">
               <p className="font-medium text-gray-900">{order.customer?.firstName} {order.customer?.lastName}</p>
               <p>{order.customer?.email}</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrderDetails;
