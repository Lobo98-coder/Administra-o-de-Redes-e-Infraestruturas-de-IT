function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-800 text-white mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <h3 className="text-lg font-bold mb-4">About OMS</h3>
            <p className="text-gray-400">
              Online Shopping Order Management System - A comprehensive solution
              for managing e-commerce orders with AI-powered insights.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="/" className="hover:text-white transition">
                  Dashboard
                </a>
              </li>
              <li>
                <a href="/orders" className="hover:text-white transition">
                  Orders
                </a>
              </li>
              <li>
                <a href="/products" className="hover:text-white transition">
                  Products
                </a>
              </li>
              <li>
                <a href="/ai-query" className="hover:text-white transition">
                  AI Query
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-4">Contact</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Email: support@oms.com</li>
              <li>Phone: +1 (555) 123-4567</li>
              <li>Address: 123 Business St, Tech City</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>
            &copy; {currentYear} Online Shopping Order Management System. All
            rights reserved.
          </p>
          <p className="mt-2 text-sm">
            DevOps Assignment Project | Built with React, Node.js, and Azure
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
