
# OMS - Online Shopping Order Management System

Sistema de Gestão de Encomendas empresarial full-stack, com consultas em linguagem natural suportadas por IA, streaming em tempo real com Azure Event Hub e arquivo de dados em cloud.

## Índice

* Features
* Arquitetura
* Quick Start (Docker)
* Credenciais por Defeito
* Estrutura do Projeto
* Documentação da API
* Integração Azure
* Agente de Consulta por IA
* Resolução de Problemas

---

## Features

### Funcionalidades de E-commerce

* **Autenticação de Utilizadores** – Registo, login e sessões baseadas em JWT
* **Catálogo de Produtos** – Navegar, pesquisar e filtrar produtos
* **Carrinho de Compras** – Adicionar/remover itens e gerir quantidades
* **Gestão de Encomendas** – Criar encomendas, acompanhar estado e histórico
* **Painel de Administração** – Gestão de produtos, utilizadores e encomendas

### Agente de Consulta por IA

* Conversão de linguagem natural para SQL
* Consultas a encomendas, produtos e utilizadores em inglês simples
* Baseado em OpenRouter AI (modelos GPT)
* Execução segura de queries (apenas SELECT)

### Integração com Azure Cloud

* **Azure Event Hubs** – Streaming de encomendas em tempo real
* **Azure Blob Storage** – Arquivo de encomendas por 10 anos
* **Stream Back em Tempo Real** – Processamento operacional on-premises

### Arquitetura Empresarial

* **3 Servidores Web Nginx** – Frontend com load balancing (configurável)
* **Traefik Reverse Proxy** – Routing dinâmico e balanceamento de carga
* **MySQL** – Armazenamento persistente de dados
* **Docker Compose** – Deployment com um único comando

---

## Arquitetura

```
┌─────────────────────────────────────────────────────────────────┐
│                         TRAEFIK (Load Balancer)                 │
│                              Port 80                            │
└─────────────────────────────────────────────────────────────────┘
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        │                          │                          │
        ▼                          ▼                          ▼
┌───────────────┐          ┌───────────────┐          ┌───────────────┐
│   Frontend    │          │    Backend    │          │   AI Agent    │
│   (Nginx)     │          │   (Node.js)   │          │   (FastAPI)   │
│   Port 3000   │          │   Port 5000   │          │   Port 8000   │
└───────────────┘          └───────────────┘          └───────────────┘
                                   │
                                   ▼
                          ┌───────────────┐
                          │     MySQL     │
                          │   Port 3306   │
                          └───────────────┘
                                   │
                    ┌──────────────┴──────────────┐
                    ▼                              ▼
           ┌───────────────┐              ┌───────────────┐
           │ Azure Event   │◄────────────►│ Azure Blob    │
           │ Hubs (Stream) │              │ Storage       │
           └───────────────┘              └───────────────┘
```

---

## Quick Start (Docker)

### Pré-requisitos

* Docker Desktop instalado e em execução
* Git para clonar o repositório

### Passo 1: Clonar o Repositório

```bash
git clone <url-do-repositorio>
cd oms-devops-project
```

### Passo 2: Configurar Variáveis de Ambiente

Criar um ficheiro `.env` na raiz do projeto:

```env
DB_HOST=mysql
DB_PORT=3306
DB_NAME=oms_db
DB_USER=oms_user
DB_PASSWORD=oms_password
MYSQL_ROOT_PASSWORD=rootpassword

JWT_SECRET=your-super-secret-jwt-key-change-this
JWT_EXPIRATION=24h

VITE_API_URL=http://localhost:5000/api
VITE_AI_URL=http://localhost/ai

OPENROUTER_API_KEY=your-openrouter-api-key

AZURE_EVENT_HUB_CONNECTION=your-event-hub-connection-string
AZURE_EVENT_HUB_NAME=oms-orders
AZURE_STORAGE_CONNECTION=your-storage-connection-string
AZURE_STORAGE_CONTAINER=order-archive
```

### Passo 3: Iniciar a Aplicação

```bash
docker compose build --no-cache --pull
docker compose up -d --build
```

Opção A: Frontend Único (default)

```bash
docker-compose up -d
```

Opção B: Frontend Escalado (3 instâncias)

```bash
docker-compose up -d --scale frontend=3
```

Aguardar cerca de 1 a 2 minutos para inicialização completa.

### Passo 4: Verificar Serviços

```bash
docker ps
```

Contentores esperados:

* oms-mysql
* oms-backend
* oms-ai-agent
* oms-devops-project-frontend-1
* oms-traefik

### Passo 5: Aceder à Aplicação

| Serviço             | URL                                                      |
| ------------------- | -------------------------------------------------------- |
| Aplicação Principal | [http://localhost](http://localhost)                     |
| Documentação da API | [http://localhost/api-docs](http://localhost/api-docs)   |
| API de Consulta IA  | [http://localhost/ai/health](http://localhost/ai/health) |
| Dashboard Traefik   | [http://localhost:8080](http://localhost:8080)           |

---

## Credenciais por Defeito

### Conta de Administrador

| Campo    | Valor           |
| -------- | --------------- |
| Email    | `admin@oms.com` |
| Password | `admin123`      |

### Perfis Disponíveis

* **Administrador** – Gestão total do sistema
* **Cliente** – Compras e histórico de encomendas

---

## Estrutura do Projeto

```
oms-devops-project/
├── backend/
├── frontend/
├── ai-agent/
├── database/
├── docker/
├── infrastructure/
├── docker-compose.yml
└── .env
```

---

## Documentação da API

A API está documentada com Swagger:

[http://localhost:5000/api-docs](http://localhost:5000/api-docs)

---

## Integração Azure

### Azure Event Hubs

* Streaming de encomendas em tempo real
* Consumo automático pelo backend
* Registo de eventos no sistema local

### Azure Blob Storage

* Arquivo automático de encomendas
* Retenção de longo prazo (10 anos)
* Cada encomenda armazenada como JSON

---

## Agente de Consulta por IA

### Utilização

1. Login na aplicação
2. Aceder à secção "AI Query"
3. Introduzir pergunta em inglês
4. Visualizar SQL, resultados e explicação

### Características Técnicas

* Queries apenas SELECT
* Suporte a joins e agregações
* Resultados em formato tabular

---

## Resolução de Problemas

### Login de Admin não funciona

```bash
docker restart oms-backend
```

### MySQL não disponível

```bash
docker logs oms-mysql
```

### Agente IA não responde

```bash
docker logs oms-ai-agent
```

### Reinício completo

```bash
docker-compose down -v
docker-compose up -d
```

---

## Desenvolvimento

### Executar sem Docker

Backend:

```bash
cd backend
npm install
npm run dev
```

Frontend:

```bash
cd frontend
npm install
npm run dev
```

AI Agent:

```bash
cd ai-agent
pip install -r requirements.txt
python src/main.py
```


