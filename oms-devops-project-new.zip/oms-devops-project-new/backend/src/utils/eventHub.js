const { EventHubProducerClient } = require("@azure/event-hubs");

const connectionString = process.env.AZURE_EVENT_HUB_CONNECTION;
const eventHubName = process.env.AZURE_EVENT_HUB_NAME;

let producerClient = null;

/**
 * Inicializar o Event Hub Producer Client
 */
function getProducerClient() {
  if (!connectionString || !eventHubName) {
    console.warn("[Azure Event Hub] Connection string or Event Hub name not provided. Events will be simulated.");
    return null;
  }

  if (!producerClient) {
    try {
      producerClient = new EventHubProducerClient(connectionString, eventHubName);
      console.log("✓ Azure Event Hub Producer initialized");
    } catch (error) {
      console.error("✗ Failed to initialize Azure Event Hub Producer:", error.message);
      return null;
    }
  }
  return producerClient;
}

/**
 * Publicar um evento no Azure Event Hub
 * @param {Object} payload Dados do evento
 * @param {String} eventType Tipo do evento
 */
async function publishEvent(payload, eventType) {
  const client = getProducerClient();
  const eventData = {
    body: {
      ...payload,
      eventType,
      timestamp: new Date().toISOString()
    }
  };

  if (client) {
    try {
      const batch = await client.createBatch();
      batch.tryAdd(eventData);
      await client.sendBatch(batch);
      console.log(`[Azure Event Hub] Real event published: ${eventType}`);
    } catch (error) {
      console.error(`[Azure Event Hub] Failed to publish real event: ${error.message}`);
      simulateEvent(payload, eventType);
    }
  } else {
    simulateEvent(payload, eventType);
  }
}

function simulateEvent(payload, eventType) {
  console.log(`[Azure Event Hub Simulation] Type: ${eventType}`);
  console.log(`[Azure Event Hub Simulation] Payload:`, JSON.stringify(payload, null, 2));
}

async function closeProducer() {
  if (producerClient) {
    await producerClient.close();
  }
}

module.exports = {
  publishEvent,
  closeProducer
};
