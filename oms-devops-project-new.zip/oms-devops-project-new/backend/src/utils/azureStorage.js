const { BlobServiceClient } = require("@azure/storage-blob");

const connectionString = process.env.AZURE_STORAGE_KEY;
const containerName = "order-archives";

let blobServiceClient = null;

function getBlobClient() {
  if (!connectionString) {
    console.warn("[Azure Storage] Connection string not provided. Archiving will be skipped.");
    return null;
  }

  if (!blobServiceClient) {
    try {
      blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
      console.log("✓ Azure Blob Storage initialized for archiving");
    } catch (error) {
      console.error("✗ Failed to initialize Azure Blob Storage:", error.message);
      return null;
    }
  }
  return blobServiceClient;
}

/**
 * arquivar o pedido no Azure Blob Storage com retenção de 10 anos
 * @param {Object} data 
 * @param {String} orderNumber 
 */
async function archiveOrder(data, orderNumber) {
  const client = getBlobClient();
  if (!client) return;

  try {
    const containerClient = client.getContainerClient(containerName);
    // Criar o conteiner se não existir
    await containerClient.createIfNotExists();

    const blobName = `orders/${new Date().getFullYear()}/${orderNumber}.json`;
    const blockBlobClient = containerClient.getBlockBlobClient(blobName);

    const uploadOptions = {
      blobHTTPHeaders: { blobContentType: "application/json" },
      metadata: {
        orderNumber: orderNumber,
        archivedAt: new Date().toISOString(),
        retention: "10 years"
      }
    };

    const content = JSON.stringify(data);
    await blockBlobClient.upload(content, content.length, uploadOptions);
    
    console.log(`[Azure Storage] Order #${orderNumber} archived successfully for 10-year retention.`);
  } catch (error) {
    console.error(`[Azure Storage] Archiving failed for order #${orderNumber}: ${error.message}`);
  }
}

module.exports = { archiveOrder };
