const express = require('express');
const router = express.Router();
const aiController = require('../controllers/ai.controller');
const { authenticate } = require('../middleware/auth');

// Routes protegidas por autenticação
router.post('/query', authenticate, aiController.query);
router.get('/examples', authenticate, aiController.getExamples);

module.exports = router;
