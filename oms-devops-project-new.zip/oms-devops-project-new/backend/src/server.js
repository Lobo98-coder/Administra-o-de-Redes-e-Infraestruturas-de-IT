// Polyfill for Web Crypto API (Required for Azure SDK on Node 18)
if (!globalThis.crypto) {
  globalThis.crypto = require("node:crypto").webcrypto;
}

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const dotenv = require("dotenv");
const swaggerUi = require("swagger-ui-express");
const swaggerJsdoc = require("swagger-jsdoc");

// Load environment variables (Check root directory)
const path = require("path");
dotenv.config({ path: path.join(__dirname, "../../.env") });
dotenv.config(); // Fallback to current dir

// Import routes
const authRoutes = require("./routes/auth.routes");
const orderRoutes = require("./routes/order.routes");
const productRoutes = require("./routes/product.routes");
const userRoutes = require("./routes/user.routes");
const aiRoutes = require("./routes/ai.routes");
const { startConsumer } = require("./workers/eventConsumer");

// Importar database conexão
const db = require("./config/database");

// Criar Express app
const app = express();
const PORT = process.env.PORT || 5000;

// ===================================
// Middleware
// ===================================
app.use(helmet()); // Security headers
app.use(
  cors({
    origin: process.env.CORS_ORIGIN
      ? process.env.CORS_ORIGIN.split(",")
      : "http://localhost:3000",
    credentials: true,
  })
);
app.use(morgan("combined")); // Logging
app.use(express.json()); // Parse JSON bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies

// ===================================
// Swagger API Documentation
// ===================================
const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "OMS API Documentation",
      version: "1.0.0",
      description:
        "API documentation for Online Shopping Order Management System",
      contact: {
        name: "API Support",
        email: "support@oms.com",
      },
    },
    servers: [
      {
        url: `http://localhost:${PORT}/api`,
        description: "Development server",
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
        },
      },
    },
  },
  apis: ["./src/routes/*.js"],
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// ===================================
// Health Check Endpoint
// ===================================
app.get("/api/health", async (req, res) => {
  try {
    // Check database connection
    await db.query("SELECT 1");

    res.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      services: {
        database: "connected",
        api: "running",
      },
    });
  } catch (error) {
    res.status(503).json({
      status: "error",
      message: "Service unavailable",
      error: error.message,
    });
  }
});

// ===================================
// API Routes
// ===================================
app.use((req, res, next) => {
  if (req.path === "/api/auth/login" && req.method === "POST") {
    console.log(`🔐 Login attempt: ${req.body.email}`);
  }
  next();
});
app.use("/api/auth", authRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/products", productRoutes);
app.use("/api/users", userRoutes);
app.use("/api/ai", aiRoutes);

// ===================================
// Root Endpoint
// ===================================
app.get("/", (req, res) => {
  res.json({
    message: "OMS API Server",
    version: "1.0.0",
    docs: "/api-docs",
  });
});

// ===================================
// 404 Handler
// ===================================
app.use((req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `Cannot ${req.method} ${req.path}`,
  });
});

// ===================================
// Global Error Handler
// ===================================
app.use((err, req, res, next) => {
  console.error("Error:", err);

  res.status(err.status || 500).json({
    error: err.name || "Internal Server Error",
    message: err.message || "Something went wrong",
    ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
  });
});

// ===================================
// Start Server
// ===================================
const server = app.listen(PORT, async () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🚀 OMS Backend Server Started                          ║
║                                                           ║
║   Environment: ${process.env.NODE_ENV || "development".padEnd(40)} ║
║   Port: ${PORT.toString().padEnd(50)} ║
║   API Docs: http://localhost:${PORT}/api-docs${" ".repeat(22)} ║
║   Health Check: http://localhost:${PORT}/api/health${" ".repeat(17)} ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);

  // Wait for DB to be really ready before background tasks
  const dbReady = await db.testConnection();

  if (dbReady) {
    // Start the background consumer for Azure Event Hub real-time stream
    startConsumer();

    // Initialize admin password on first startup
    await initializeAdminPassword();
  } else {
    console.error(
      "⚠️ Backend starting without database connectivity. Background tasks and Admin Init skipped."
    );
  }
});

// Initialize admin password with proper bcrypt hash
async function initializeAdminPassword() {
  try {
    const bcrypt = require("bcryptjs");
    console.log("--- Admin Account Check ---");
    const [users] = await db.query(
      "SELECT password_hash, is_active FROM users WHERE email = ?",
      ["admin@oms.com"]
    );

    const newHash = await bcrypt.hash("admin123", 10);

    if (users.length > 0) {
      // Always reset to admin123 on startup to ensure consistency for the presentation
      await db.query(
        "UPDATE users SET password_hash = ?, is_active = 1 WHERE email = ?",
        [newHash, "admin@oms.com"]
      );
      console.log(
        "✓ Admin account updated to default (admin@oms.com / admin123)"
      );
    } else {
      console.log(
        "⚠️ Admin account not found in database. Please check your SQL seeds."
      );
    }
    console.log("---------------------------");
  } catch (error) {
    console.error("Admin password init error:", error.message);
  }
}

// ===================================
// Graceful Shutdown
// ===================================
process.on("SIGTERM", () => {
  console.log("SIGTERM signal received: closing HTTP server");
  server.close(() => {
    console.log("HTTP server closed");
    db.end();
  });
});

module.exports = app;
