const mysql = require("mysql2/promise");

// Database configuração
const dbConfig = {
  host: process.env.DB_HOST || "localhost",
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || "oms_user",
  password: process.env.DB_PASSWORD || "oms_password",
  database: process.env.DB_NAME || "oms_db",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0,
  ssl:
    process.env.AZURE_DB_SSL === "true"
      ? {
          rejectUnauthorized: false, // Comum para o Azure Flexible Server, a menos que seja fornecida uma AC específica.
      : null,
};

// Criar connection pool
const pool = mysql.createPool(dbConfig);

// Testar conexão com o banco de dados
async function testConnection(retries = 5, delay = 2000) {
  for (let i = 0; i < retries; i++) {
    try {
      const connection = await pool.getConnection();
      console.log("✓ Database connected successfully");
      connection.release();
      return true;
    } catch (error) {
      console.warn(
        `[Attempt ${i + 1}/${retries}] Database connection failed: ${
          error.message
        }`
      );
      if (i < retries - 1) {
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }
  console.error("✗ All database connection attempts failed.");
  return false;
}

async function query(sql, params) {
  try {
    // Usar pool para executar a query
    const [results, fields] = await pool.query(sql, params);
    return [results, fields];
  } catch (error) {
    console.error("Query error:", error);
    console.error("SQL:", sql);
    console.error("Params:", params);
    throw error;
  }
}

// Exportar pool e função de query
module.exports = {
  pool,
  query,
  testConnection,
};
