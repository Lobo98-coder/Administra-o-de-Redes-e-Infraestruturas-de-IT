const db = require('../config/database');

// UPDATED: 
// obter todos os produtos com pesquisa, filtro e paginação
exports.getAllProducts = async (req, res) => {
  try {
    const { search, category, page = 1, limit = 20 } = req.query;
    const pageNum = parseInt(page) || 1;
    const limitNum = parseInt(limit) || 20;
    const offset = (pageNum - 1) * limitNum;

    let query = `
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.is_active = TRUE
    `;
    const params = [];

    // persquisar por nome ou descrição
    if (search) {
      query += ' AND (p.name LIKE ? OR p.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    // Filtrar por categoria
    if (category) {
      query += ' AND p.category_id = ?';
      params.push(category);
    }

    query += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
    params.push(limitNum, offset);

    const [products] = await db.query(query, params);

    // obter total count para paginação
    let countQuery = 'SELECT COUNT(*) as total FROM products WHERE is_active = TRUE';
    const countParams = [];

    if (search) {
      countQuery += ' AND (name LIKE ? OR description LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`);
    }

    if (category) {
      countQuery += ' AND category_id = ?';
      countParams.push(category);
    }

    const [countResult] = await db.query(countQuery, countParams);
    const total = countResult[0].total;

    res.json({
      products: products.map(p => ({
        id: p.id,
        name: p.name,
        description: p.description,
        sku: p.sku,
        price: parseFloat(p.price),
        stockQuantity: p.stock_quantity,
        lowStockThreshold: p.low_stock_threshold,
        imageUrl: p.image_url,
        category: {
          id: p.category_id,
          name: p.category_name
        },
        createdAt: p.created_at
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        pages: Math.ceil(total / limitNum)
      }
    });
  } catch (error) {
    console.error('Get products error:', error);
    res.status(500).json({
      error: 'Failed to get products',
      message: error.message
    });
  }
};

// Obter produto por ID
exports.getProductById = async (req, res) => {
  try {
    const { id } = req.params;

    const [products] = await db.query(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.id = ? AND p.is_active = TRUE
    `, [id]);

    if (products.length === 0) {
      return res.status(404).json({
        error: 'Product not found',
        message: 'Product does not exist'
      });
    }

    const product = products[0];

    res.json({
      product: {
        id: product.id,
        name: product.name,
        description: product.description,
        sku: product.sku,
        price: parseFloat(product.price),
        costPrice: parseFloat(product.cost_price),
        stockQuantity: product.stock_quantity,
        lowStockThreshold: product.low_stock_threshold,
        imageUrl: product.image_url,
        weight: parseFloat(product.weight),
        dimensions: product.dimensions,
        category: {
          id: product.category_id,
          name: product.category_name
        },
        createdAt: product.created_at,
        updatedAt: product.updated_at
      }
    });
  } catch (error) {
    console.error('Get product error:', error);
    res.status(500).json({
      error: 'Failed to get product',
      message: error.message
    });
  }
};

// Criar produtos (Admin only)
exports.createProduct = async (req, res) => {
  try {
    const {
      categoryId, name, description, sku, price, costPrice,
      stockQuantity, lowStockThreshold, imageUrl, weight, dimensions
    } = req.body;

    // Validar campos obrigatórios
    if (!name || !sku || !price) {
      return res.status(400).json({
        error: 'Missing required fields',
        message: 'Name, SKU, and price are required'
      });
    }

    // Verifica se SKU já existe
    const [existing] = await db.query(
      'SELECT id FROM products WHERE sku = ?',
      [sku]
    );

    if (existing.length > 0) {
      return res.status(400).json({
        error: 'SKU already exists',
        message: 'A product with this SKU already exists'
      });
    }

    // Inserir produtos
    const [result] = await db.query(`
      INSERT INTO products (category_id, name, description, sku, price, cost_price,
                           stock_quantity, low_stock_threshold, image_url, weight, dimensions)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      categoryId || null, name, description || null, sku, price, costPrice || null,
      stockQuantity || 0, lowStockThreshold || 10, imageUrl || null,
      weight || null, dimensions || null
    ]);

    res.status(201).json({
      message: 'Product created successfully',
      product: {
        id: result.insertId,
        name,
        sku,
        price
      }
    });
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({
      error: 'Failed to create product',
      message: error.message
    });
  }
};

// Atualizar Produto (Admin only)
exports.updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      categoryId, name, description, price, costPrice,
      stockQuantity, lowStockThreshold, imageUrl, weight, dimensions, isActive
    } = req.body;

    // Verifica se produto já existe
    const [products] = await db.query('SELECT id FROM products WHERE id = ?', [id]);

    if (products.length === 0) {
      return res.status(404).json({
        error: 'Product not found',
        message: 'Product does not exist'
      });
    }

    const updates = [];
    const values = [];

    if (categoryId !== undefined) { updates.push('category_id = ?'); values.push(categoryId); }
    if (name) { updates.push('name = ?'); values.push(name); }
    if (description !== undefined) { updates.push('description = ?'); values.push(description); }
    if (price) { updates.push('price = ?'); values.push(price); }
    if (costPrice !== undefined) { updates.push('cost_price = ?'); values.push(costPrice); }
    if (stockQuantity !== undefined) { updates.push('stock_quantity = ?'); values.push(stockQuantity); }
    if (lowStockThreshold !== undefined) { updates.push('low_stock_threshold = ?'); values.push(lowStockThreshold); }
    if (imageUrl !== undefined) { updates.push('image_url = ?'); values.push(imageUrl); }
    if (weight !== undefined) { updates.push('weight = ?'); values.push(weight); }
    if (dimensions !== undefined) { updates.push('dimensions = ?'); values.push(dimensions); }
    if (isActive !== undefined) { updates.push('is_active = ?'); values.push(isActive); }

    if (updates.length === 0) {
      return res.status(400).json({
        error: 'No updates provided',
        message: 'Please provide at least one field to update'
      });
    }

    values.push(id);

    await db.query(
      `UPDATE products SET ${updates.join(', ')} WHERE id = ?`,
      values
    );

    res.json({
      message: 'Product updated successfully'
    });
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({
      error: 'Failed to update product',
      message: error.message
    });
  }
};

// Eliminar Produto (Admin only - Hybrid strategy)
exports.deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;

    const [products] = await db.query('SELECT id FROM products WHERE id = ?', [id]);

    if (products.length === 0) {
      return res.status(404).json({
        error: 'Product not found',
        message: 'Product does not exist'
      });
    }

    // Verifica se o produto é usado em order_items
    const [usage] = await db.query(
      'SELECT COUNT(*) as count FROM order_items WHERE product_id = ?',
      [id]
    );

    if (usage[0].count > 0) {
      // produto é usado em orders -> Soft Delete (set is_active = FALSE)
      await db.query(
        'UPDATE products SET is_active = FALSE WHERE id = ?',
        [id]
      );
      return res.json({
        message: 'Product archived successfully. It cannot be permanently deleted because it exists in previous orders.'
      });
    } else {
      // Produto não está a ser usado  -> Hard Delete (remove from DB)
      await db.query('DELETE FROM products WHERE id = ?', [id]);
      return res.json({
        message: 'Product permanently deleted successfully'
      });
    }

  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({
      error: 'Failed to delete product',
      message: error.message
    });
  }
};
