const db = require('../config/database');

exports.query = async (req, res) => {
  try {
    const { question } = req.body;
    
    if (!question) {
      return res.status(400).json({ error: 'Question is required' });
    }

    console.log('AI Agent received question:', question);

    let sqlQuery = '';
    let params = [];
    let explanation = '';

    const lowerQ = question.toLowerCase();

    // ---------------------------------------------------------
    // Simple Rule-Based NLP 
    // ---------------------------------------------------------

    // 1. "Listar todos os produtos" / "Mostrar produtos"
    if (lowerQ.includes('product') && (lowerQ.includes('list') || lowerQ.includes('show') || lowerQ.includes('all'))) {
      sqlQuery = 'SELECT id, name, price, stock_quantity FROM products WHERE is_active = TRUE LIMIT 10';
      explanation = 'I found specific details for the active products you asked about.';
    }
    
    // 2. "Quantos Orders" / "Numero total de Orders"
    else if (lowerQ.includes('how many orders') || lowerQ.includes('total orders')) {
      sqlQuery = 'SELECT COUNT(*) as total_orders FROM orders';
      explanation = 'I calculated the total number of orders placed in the system.';
    }

    // 3. "Mostrar Orders" / "Listar orders"
    else if (lowerQ.includes('orders') && (lowerQ.includes('show') || lowerQ.includes('list'))) {
      sqlQuery = 'SELECT id, order_number, total_amount, status FROM orders ORDER BY created_at DESC LIMIT 5';
      explanation = 'Here are the most recent 5 orders found in the database.';
    }

    // 4. "Produtos mais vendidos" / "Best selling product"
    else if (lowerQ.includes('best selling') || lowerQ.includes('top product')) {
      sqlQuery = `
        SELECT p.name, SUM(oi.quantity) as total_sold 
        FROM order_items oi 
        JOIN products p ON oi.product_id = p.id 
        GROUP BY p.id, p.name 
        ORDER BY total_sold DESC 
        LIMIT 1
      `;
      explanation = 'I identified the product with the highest sales volume.';
    }

    // 5. "Baixo Stock "
    else if (lowerQ.includes('low stock') || lowerQ.includes('run out')) {
      sqlQuery = 'SELECT name, stock_quantity FROM products WHERE stock_quantity < low_stock_threshold';
      explanation = 'I checked the inventory and found these products are below their stock threshold.';
    }

    // 6. "Total revenue" / "Sales"
    else if (lowerQ.includes('revenue') || lowerQ.includes('sales')) {
      sqlQuery = "SELECT SUM(total_amount) as total_revenue FROM orders WHERE status != 'cancelled'";
      explanation = 'I summed up the total amount from all non-cancelled orders.';
    }

    // Default Fallback
    else {
      return res.json({
        answer: "I'm sorry, I didn't verify that query. Try asking 'Show recent orders', 'List products', or 'Total revenue'.",
        sql: null,
        data: []
      });
    }

    // Executar SQL gerado
    const [results] = await db.query(sqlQuery, params);

    res.json({
      explanation: explanation,
      sql: sqlQuery,
      data: results
    });

  } catch (error) {
    console.error('AI Query Error:', error);
    res.status(500).json({ error: 'Failed to process AI query', details: error.message });
  }
};

exports.getExamples = (req, res) => {
  res.json({
    examples: [
      "Show me all products",
      "How many orders do we have?",
      "What is the total revenue?",
      "List products with low stock",
      "What is the best selling product?"
    ]
  });
};
