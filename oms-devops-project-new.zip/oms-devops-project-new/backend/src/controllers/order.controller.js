const db = require('../config/database');
const eventHub = require('../utils/eventHub');
const azureStorage = require('../utils/azureStorage');

// Obter todos os orders (com paginação e filtro por status)
exports.getAllOrders = async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const pageNum = parseInt(page) || 1;
    const limitNum = parseInt(limit) || 10;
    const offset = (pageNum - 1) * limitNum;
    const userId = req.user.role === 'admin' ? null : req.user.id;

    let query = `
      SELECT o.*, 
             u.email as user_email, 
             u.first_name, 
             u.last_name,
             COUNT(oi.id) as item_count
      FROM orders o
      JOIN users u ON o.user_id = u.id
      LEFT JOIN order_items oi ON o.id = oi.order_id
      WHERE 1=1
    `;
    const params = [];

    // Filtrar por userId se não for admin
    if (userId) {
      query += ' AND o.user_id = ?';
      params.push(userId);
    }

    // Filtrar por status se fornecido
    if (status) {
      query += ' AND o.status = ?';
      params.push(status);
    }

    query += ' GROUP BY o.id ORDER BY o.created_at DESC LIMIT ? OFFSET ?';
    params.push(limitNum, offset);

    const [orders] = await db.query(query, params);

    // Obter total 
    let countQuery = 'SELECT COUNT(*) as total FROM orders WHERE 1=1';
    const countParams = [];

    if (userId) {
      countQuery += ' AND user_id = ?';
      countParams.push(userId);
    }

    if (status) {
      countQuery += ' AND status = ?';
      countParams.push(status);
    }

    const [countResult] = await db.query(countQuery, countParams);
    const total = countResult[0].total;

    res.json({
      orders: orders.map(order => ({
        id: order.id,
        orderNumber: order.order_number,
        status: order.status,
        paymentStatus: order.payment_status,
        subtotal: parseFloat(order.subtotal),
        taxAmount: parseFloat(order.tax_amount),
        shippingAmount: parseFloat(order.shipping_amount),
        discountAmount: parseFloat(order.discount_amount),
        totalAmount: parseFloat(order.total_amount),
        currency: order.currency,
        itemCount: order.item_count,
        user: {
          email: order.user_email,
          firstName: order.first_name,
          lastName: order.last_name
        },
        createdAt: order.created_at,
        updatedAt: order.updated_at
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        pages: Math.ceil(total / limitNum)
      }
    });
  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({
      error: 'Failed to get orders',
      message: error.message
    });
  }
};

// Obter order por ID
exports.getOrderById = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.role === 'admin' ? null : req.user.id;

    let query = `
      SELECT o.*, 
             u.email as user_email, 
             u.first_name, 
             u.last_name
      FROM orders o
      JOIN users u ON o.user_id = u.id
      WHERE o.id = ?
    `;
    const params = [id];

    if (userId) {
      query += ' AND o.user_id = ?';
      params.push(userId);
    }

    const [orders] = await db.query(query, params);

    if (orders.length === 0) {
      return res.status(404).json({
        error: 'Order not found',
        message: 'Order does not exist or you do not have permission to view it'
      });
    }

    const order = orders[0];

    // Obter itens do order
    const [items] = await db.query(`
      SELECT oi.*, p.name as product_name, p.image_url
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = ?
    `, [id]);

    // Obter info de pagamento
    const [payments] = await db.query(
      'SELECT * FROM payments WHERE order_id = ?',
      [id]
    );

    // Obter info de envio
    const [shipments] = await db.query(
      'SELECT * FROM shipments WHERE order_id = ?',
      [id]
    );

    res.json({
      order: {
        id: order.id,
        orderNumber: order.order_number,
        status: order.status,
        paymentStatus: order.payment_status,
        subtotal: parseFloat(order.subtotal),
        taxAmount: parseFloat(order.tax_amount),
        shippingAmount: parseFloat(order.shipping_amount),
        discountAmount: parseFloat(order.discount_amount),
        totalAmount: parseFloat(order.total_amount),
        currency: order.currency,
        notes: order.notes,
        user: {
          email: order.user_email,
          firstName: order.first_name,
          lastName: order.last_name
        },
        items: items.map(item => ({
          id: item.id,
          productId: item.product_id,
          productName: item.product_name,
          productSku: item.product_sku,
          quantity: item.quantity,
          unitPrice: parseFloat(item.unit_price),
          subtotal: parseFloat(item.subtotal),
          taxAmount: parseFloat(item.tax_amount),
          total: parseFloat(item.total),
          imageUrl: item.image_url
        })),
        payments: payments.map(p => ({
          id: p.id,
          method: p.payment_method,
          transactionId: p.transaction_id,
          amount: parseFloat(p.amount),
          status: p.status,
          paidAt: p.paid_at
        })),
        shipments: shipments.map(s => ({
          id: s.id,
          trackingNumber: s.tracking_number,
          carrier: s.carrier,
          status: s.status,
          shippedAt: s.shipped_at,
          estimatedDelivery: s.estimated_delivery,
          deliveredAt: s.delivered_at
        })),
        createdAt: order.created_at,
        updatedAt: order.updated_at
      }
    });
  } catch (error) {
    console.error('Get order error:', error);
    res.status(500).json({
      error: 'Failed to get order',
      message: error.message
    });
  }
};

// Criar novo order
exports.createOrder = async (req, res) => {
  const connection = await db.pool.getConnection();
  
  try {
    await connection.beginTransaction();

    const { items, shippingAddress, notes } = req.body;
    const userId = req.user.id;

    if (!items || items.length === 0) {
      throw new Error('Order must contain at least one item');
    }

    // Calcular totais
    let subtotal = 0;
    const orderItems = [];

    for (const item of items) {
      const [products] = await connection.query(
        'SELECT * FROM products WHERE id = ? AND is_active = TRUE',
        [item.productId]
      );

      if (products.length === 0) {
        throw new Error(`Product ${item.productId} not found or inactive`);
      }

      const product = products[0];

      if (product.stock_quantity < item.quantity) {
        throw new Error(`Insufficient stock for product ${product.name}`);
      }

      const itemSubtotal = product.price * item.quantity;
      const itemTax = itemSubtotal * 0.1; // 10% tax
      const itemTotal = itemSubtotal + itemTax;

      subtotal += itemSubtotal;

      orderItems.push({
        productId: product.id,
        productName: product.name,
        productSku: product.sku,
        quantity: item.quantity,
        unitPrice: product.price,
        subtotal: itemSubtotal,
        taxAmount: itemTax,
        total: itemTotal
      });
    }

    const taxAmount = subtotal * 0.1;
    const shippingAmount = subtotal > 100 ? 0 : 10; // Free shipping quando acima de $100
    const totalAmount = subtotal + taxAmount + shippingAmount;

    // Gerar order number
    const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;

    // Inserir order
    const [orderResult] = await connection.query(`
      INSERT INTO orders (user_id, order_number, status, payment_status, 
                         subtotal, tax_amount, shipping_amount, total_amount, notes)
      VALUES (?, ?, 'pending', 'pending', ?, ?, ?, ?, ?)
    `, [userId, orderNumber, subtotal, taxAmount, shippingAmount, totalAmount, notes || null]);

    const orderId = orderResult.insertId;

    // Inserir itens do order e atualizar stock
    for (const item of orderItems) {
      await connection.query(`
        INSERT INTO order_items (order_id, product_id, product_name, product_sku,
                                quantity, unit_price, subtotal, tax_amount, total)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        orderId, item.productId, item.productName, item.productSku,
        item.quantity, item.unitPrice, item.subtotal, item.taxAmount, item.total
      ]);

      // Atualizar stock do produto
      await connection.query(
        'UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?',
        [item.quantity, item.productId]
      );
    }

    // Criar evento de order para o Azure Event Hub
    await connection.query(`
      INSERT INTO events (event_type, entity_type, entity_id, event_data)
      VALUES ('order.created', 'order', ?, ?)
    `, [orderId, JSON.stringify({ orderId, orderNumber, totalAmount, userId })]);

    // Limpar carrinho do user quando o order é criado com sucesso
    await connection.query(
      'DELETE FROM cart WHERE user_id = ?',
      [userId]
    );

    await connection.commit();

    // =====================================================
    // ARCHITECTURE REQUIREMENT: Azure Cloud Integration
    // =====================================================
    
    // 1. Fluxo de dados de alta magnitude (Azure Event Hubs)
    await eventHub.publishEvent({
      orderId: orderId,
      orderNumber: orderNumber,
      amount: totalAmount,
      userId: userId,
      items: orderItems.map(item => ({ productName: item.productName, quantity: item.quantity }))
    }, 'ORDER_CREATED');

    // 2. Arquivamento de dados para retenção de 10 anos (Armazenamento Azure)
    await azureStorage.archiveOrder({
      orderId,
      orderNumber,
      totalAmount,
      items: orderItems,
      userId,
      createdAt: new Date().toISOString()
    }, orderNumber);

    // =====================================================

    res.status(201).json({
      message: 'Order created successfully',
      orderId,
      orderNumber,
      items: orderItems
    });
  } catch (error) {
    await connection.rollback();
    console.error('Create order error:', error);
    res.status(500).json({
      error: 'Failed to create order',
      message: error.message
    });
  } finally {
    connection.release();
  }
};

// Atualizar order (not status, apenas notas)
exports.updateOrder = async (req, res) => {
  try {
    const { id } = req.params;
    const { notes } = req.body;
    const userId = req.user.role === 'admin' ? null : req.user.id;

    // Verificar order existente e pertence ao user
    let checkQuery = 'SELECT * FROM orders WHERE id = ?';
    const checkParams = [id];

    if (userId) {
      checkQuery += ' AND user_id = ?';
      checkParams.push(userId);
    }

    const [orders] = await db.query(checkQuery, checkParams);

    if (orders.length === 0) {
      return res.status(404).json({
        error: 'Order not found',
        message: 'Order does not exist or you do not have permission to update it'
      });
    }

    // Atualizar order
    await db.query(
      'UPDATE orders SET notes = ? WHERE id = ?',
      [notes, id]
    );

    res.json({
      message: 'Order updated successfully'
    });
  } catch (error) {
    console.error('Update order error:', error);
    res.status(500).json({
      error: 'Failed to update order',
      message: error.message
    });
  }
};

// Cancelar order
exports.cancelOrder = async (req, res) => {
  const connection = await db.getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;
    const userId = req.user.role === 'admin' ? null : req.user.id;

    // Check order
    let query = 'SELECT * FROM orders WHERE id = ?';
   const params = [id];

    if (userId) {
      query += ' AND user_id = ?';
      params.push(userId);
    }

    const [orders] = await connection.query(query, params);

    if (orders.length === 0) {
      throw new Error('Order not found or you do not have permission');
    }

    const order = orders[0];

    if (order.status === 'delivered' || order.status === 'cancelled') {
      throw new Error(`Cannot cancel order with status: ${order.status}`);
    }

    // Restaurar stock
    const [items] = await connection.query(
      'SELECT product_id, quantity FROM order_items WHERE order_id = ?',
      [id]
    );

    for (const item of items) {
      await connection.query(
        'UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?',
        [item.quantity, item.product_id]
      );
    }

    // Atualizar order status
    await connection.query(
      'UPDATE orders SET status = ?, payment_status = ? WHERE id = ?',
      ['cancelled', 'refunded', id]
    );

    // Criar evento
    await connection.query(`
      INSERT INTO events (event_type, entity_type, entity_id, event_data)
      VALUES ('order.cancelled', 'order', ?, ?)
    `, [id, JSON.stringify({ orderId: id, orderNumber: order.order_number })]);

    await connection.commit();

    res.json({
      message: 'Order cancelled successfully'
    });
  } catch (error) {
    await connection.rollback();
    console.error('Cancel order error:', error);
    res.status(500).json({
      error: 'Failed to cancel order',
      message: error.message
    });
  } finally {
    connection.release();
  }
};

// Atualizar order status (Admin only)
exports.updateOrderStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, paymentStatus } = req.body;

    const [orders] = await db.query('SELECT * FROM orders WHERE id = ?', [id]);

    if (orders.length === 0) {
      return res.status(404).json({
        error: 'Order not found',
        message: 'Order does not exist'
      });
    }

    const updateFields = [];
    const updateValues = [];

    if (status) {
      updateFields.push('status = ?');
      updateValues.push(status);
    }

    if (paymentStatus) {
      updateFields.push('payment_status = ?');
      updateValues.push(paymentStatus);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({
        error: 'No updates provided',
        message: 'Please provide status or paymentStatus to update'
      });
    }

    updateValues.push(id);

    await db.query(
      `UPDATE orders SET ${updateFields.join(', ')} WHERE id = ?`,
      updateValues
    );

    // Criar evento
    await db.query(`
      INSERT INTO events (event_type, entity_type, entity_id, event_data)
      VALUES ('order.updated', 'order', ?, ?)
    `, [id, JSON.stringify({ orderId: id, status, paymentStatus })]);

    // Integração real usando @azure/event-hubs
    await eventHub.publishEvent({
      orderId: id,
      status,
      paymentStatus,
      updatedAt: new Date().toISOString()
    }, 'ORDER_UPDATED');

    res.json({
      message: 'Order status updated successfully'
    });
  } catch (error) {
    console.error('Update order status error:', error);
    res.status(500).json({
      error: 'Failed to update order status',
      message: error.message
    });
  }
};
