const { EventHubConsumerClient, earliestEventPosition } = require("@azure/event-hubs");
const db = require('../config/database');

const connectionString = process.env.AZURE_EVENT_HUB_CONNECTION;
const eventHubName = process.env.AZURE_EVENT_HUB_NAME;
const consumerGroup = process.env.AZURE_EVENT_HUB_CONSUMER_GROUP || "$Default";

async function startConsumer() {
  if (!connectionString || !eventHubName) {
    console.warn("[Azure Event Hub Consumer] Configuration missing. Skipping consumer start.");
    return;
  }

  try {
    const consumerClient = new EventHubConsumerClient(consumerGroup, connectionString, eventHubName);

    console.log("✓ Azure Event Hub Consumer started (Listening for real-time stream)");

    const subscription = consumerClient.subscribe({
      processEvents: async (events, context) => {
        if (events.length === 0) return;

        for (const event of events) {
          const body = event.body;
          console.log(`\n🌊 [Real-Time Stream Back] Received event from Azure:`);
          console.log(`   Type: ${body.eventType}`);
          console.log(`   Data: ${JSON.stringify(body, null, 2)}`);
          
          // Here is where "On-Prem Operational Processing" would happen
          // exemplo: atualizar estoque, notificar equipe de expedição, etc.
          await processLocalTask(body);
        }
      },
      processError: async (err, context) => {
        console.error(`[Azure Event Hub Consumer] Error: ${err.message}`);
      }
    }, { startPosition: earliestEventPosition });

    // lidar com encerramento gracioso
    process.on("SIGINT", async () => {
      await subscription.close();
      await consumerClient.close();
      console.log("[Azure Event Hub Consumer] Stopped.");
    });

  } catch (error) {
    console.error(`[Azure Event Hub Consumer] Failed to start: ${error.message}`);
  }
}

async function processLocalTask(event) {
  if (event.eventType === 'ORDER_CREATED') {
    try {
      // primeiro passo: verificar se o pedido existe localmente
      // (Azure Event Hub pode ter um pequeno atraso, então o pedido pode não estar lá ainda)
      const [rows] = await db.query('SELECT id FROM orders WHERE id = ?', [event.orderId]);
      
      if (rows.length === 0) {
        console.warn(`⚠️ [On-Prem Processor] Order #${event.orderNumber} not found in local DB. Skipping operational task.`);
        return;
      }

      console.log(`✅ [On-Prem Processor] Processing Order #${event.orderNumber} locally for real-time operations.`);
      
      // Passo 2§: criar uma tarefa na fila de expedição local
      await db.query(`
        INSERT INTO warehouse_queue (order_id, order_number, priority, task_status)
        VALUES (?, ?, 'normal', 'pending')
      `, [event.orderId, event.orderNumber]);

      console.log(`📦 [Warehouse Queue] Task created for Order #${event.orderNumber}.`);
    } catch (error) {
      console.error(`❌ [On-Prem Processor] Failed to update operational DB: ${error.message}`);
    }
  }
}

module.exports = { startConsumer };
