/**
 * Reset Admin Password Script
 * Usage: node scripts/reset-admin-password.js
 * Sets admin@oms.com password to 'admin123'
 */
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

async function resetAdminPassword() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'mysql',
    user: process.env.DB_USER || 'oms_user',
    password: process.env.DB_PASSWORD || 'oms_password',
    database: process.env.DB_NAME || 'oms_db'
  });

  try {
    const password = 'admin123';
    const hash = await bcrypt.hash(password, 10);
    
    await conn.execute(
      'UPDATE users SET password_hash = ? WHERE email = ?',
      [hash, 'admin@oms.com']
    );
    
    console.log('✓ Admin password reset to: admin123');
    console.log('  Email: admin@oms.com');
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await conn.end();
  }
}

resetAdminPassword();
