-- Admin password reset script
-- Run this after fresh deployment to set admin password to 'admin123'
-- This is called by the backend on startup if the admin has a placeholder password

-- The password hash will be set by the backend initialization script
-- For manual reset, use: docker exec oms-backend node scripts/reset-admin-password.js
