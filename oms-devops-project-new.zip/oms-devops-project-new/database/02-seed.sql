-- ===================================
-- OMS Database Seeding (Simulated Data)
-- ===================================

-- 1. Insert Categories
INSERT INTO categories (name, description, slug) VALUES 
('Electronics', 'Gadgets, phones, and more', 'electronics'),
('Clothing', 'Apparel and fashion', 'clothing'),
('Home & Garden', 'Furniture and decor', 'home-garden');

-- 2. Insert Products
INSERT INTO products (category_id, name, description, sku, price, stock_quantity, image_url) VALUES 
(1, 'Gaming Mouse', 'High precision optical mouse', 'ELEC-MOUSE-001', 59.99, 150, 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=500'),
(1, 'Mechanical Keyboard', 'RGB Backlit mechanical keyboard', 'ELEC-KBD-002', 129.50, 45, 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=500'),
(2, 'Premium Hoodie', 'Comfortable cotton hoodie', 'CLTH-HOOD-001', 45.00, 200, 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500'),
(3, 'Smart Desk Lamp', 'Adjustable LED desk lamp', 'HOME-LAMP-001', 35.00, 12, 'https://images.unsplash.com/photo-1534073828943-f801091bb18c?w=500');

-- 3. Insert Customers
INSERT INTO users (email, password_hash, first_name, last_name, role) VALUES 
('john.doe@example.com', '$2b$10$rGYvW8qZqJX8xPQiR9.jFuKHPJ5xC.VqZ8QxH4rGYvW8qZqJX8xPQ', 'John', 'Doe', 'customer'),
('jane.smith@example.com', '$2b$10$rGYvW8qZqJX8xPQiR9.jFuKHPJ5xC.VqZ8QxH4rGYvW8qZqJX8xPQ', 'Jane', 'Smith', 'customer');

-- 4. Insert Addresses
INSERT INTO addresses (user_id, address_type, street_address, city, state, postal_code) VALUES 
(2, 'shipping', '123 Tech Lane', 'San Francisco', 'CA', '94105'),
(3, 'shipping', '456 Garden St', 'Austin', 'TX', '78701');

-- 5. Insert Orders
INSERT INTO orders (user_id, order_number, status, payment_status, subtotal, tax_amount, shipping_amount, total_amount) VALUES 
(2, 'ORD-2025-001', 'delivered', 'paid', 189.49, 18.95, 0.00, 208.44),
(2, 'ORD-2025-002', 'processing', 'pending', 45.00, 4.50, 10.00, 59.50),
(3, 'ORD-2025-003', 'pending', 'pending', 35.00, 3.50, 10.00, 48.50);

-- 6. Insert Order Items
INSERT INTO order_items (order_id, product_id, product_name, product_sku, quantity, unit_price, subtotal, tax_amount, total) VALUES 
(1, 1, 'Gaming Mouse', 'ELEC-MOUSE-001', 1, 59.99, 59.99, 6.00, 65.99),
(1, 2, 'Mechanical Keyboard', 'ELEC-KBD-002', 1, 129.50, 129.50, 12.95, 142.45),
(2, 3, 'Premium Hoodie', 'CLTH-HOOD-001', 1, 45.00, 45.00, 4.50, 49.50),
(3, 4, 'Smart Desk Lamp', 'HOME-LAMP-001', 1, 35.00, 35.00, 3.50, 38.50);
